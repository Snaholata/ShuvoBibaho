<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <title>ShuvoBibaho| A Trustable Wedding Planning Site</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="healthtips.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="swiper.min.css">
    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
</head>
<body>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    
    
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
        <img src="logo-modified.png">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="boot.php">Home</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Blog
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                  <a class="dropdown-item" href="#">Health Tips</a>
                  <a class="dropdown-item" href="makupblog.php">Makeup Guides</a>
                  <a class="dropdown-item" href="aos.php">Menu Idea</a>
                </div>
            </li>
          

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Vendor
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                    <a class="dropdown-item" href="photographer.php">Photographer</a>
                    <a class="dropdown-item" href="mvenue.php">Venues</a>
                    <a class="dropdown-item" href="mart.php">Makeup Artist</a>
                    <a class="dropdown-item" href="eventplanner.php">Event Manager</a>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="clientreview.php
                ">Client Review</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pofile1.php">Your Profile</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="mhome.php">Logout</a>
            </li>
           
            
          </ul>
         
        </div>
      </div>
      </nav>
      
    <section class="discover-our-story">
        <div class="container">
            <div class="info">
                <div class="animate-left">
                    <div class="global-headline">
                        <h2 class="sub-headline">
                            <span class="first-letter">H</span>ealth
                        </h2>
                        <h1 class="headline">Tips For Brides</h1>
                        <div class="asterisk"<i class="fas fa-asterisk"></i></div>
                    </div>
                    <p>
                        Who doesn't want glowing beautiful skin and good health condintion on their big day? 
                        Well, we all do, but makeup cannot always get the job done 
                        and you don’t always have to go for super expensive laser treatments 
                        or splurge on expensive beauty regimens. At home we can easily follow
                        some health tips to get a glowing skin and fit n fine health on our big day!
                    </p>
                    <a href="#" class="btn body-btn">Contact us</a>
                </div>
                <div class="animate-right">
                   
                </div>  
            </div>
        </div>
    </section>
    <section class="tasteful-recipes between">
        <div class="container">
            <div class="global-headline">
                <div class="animate-top">
                      <h1 class="headline headline-dark">Get a</h1>
                        <h2 class="sub-headline">
                            <span class="first-letter">G</span>lowing
                        </h2>
                </div>

                <div class="animate-bottom">
                    <h1 class="headline headline-dark">Skin & Great Health</h1>
                </div>
                
            </div>
        
        </div>
    </section>
    

    <section class="discover-our-menu">
        <div class="container">
            <div class="info">
                <div class="image-group animate-discover-menu-right">
                    

                    
                        <img src="ht2.jpg" width="250" height="200">
                    
                    
                        <img src="ht3.jpg" width="250" height="200">
                    
                    
                        <img src="ht4.jpg" width="250" height="200">
                    
                </div>
             
                
                <div class="animate-right1">
                    <div class="global-headline">
                        <h2 class="sub-headline animate-discover-menu-left">
                            <span class="first-letter">D</span>IY Masks
                        </h2>
                        <h1 class="headline animate-discover-menu-right"> For Glowing Bridal Skin </h1>
                        <div class="asterisk"<i class="fa fa-asterisk"></i></div>
                    </div>
                    <p>
                    DIY masks are easy to make and if you regularly take care of your skin 
                    you are sure to get desired results. And guess what they are chemical free 
                    so you don’t have to worry about ending up to ruining your skin. 
                    </p>
                    <a href="https://allisongoddardmd.com/8-best-diy-face-masks-for-every-skin-type-according-to-dermatologists/" class="btn body-btn">View More</a>
                    
                   
                    
                </div>
            </div>
            
        </div>
    </section>

   
<div class="perfect-blend">
            <div class="global-headline">
                <div class="animate-top">
                        <h2 class="sub-headline">
                            <span class="first-letter">T</span>op Hair Care
                        </h2>
                </div>

                <div class="animate-bottom">
                    <h1 class="headline headline-dark">Tips For The Bride To Be</h1>
                </div>
            </div>
            <div class="perfect-blend-between">
                <div class="more-recipes-image">
                    <img src="ht5.png" width="500px" height="600px">
               
                
                <p>
                    Focus on your skin and do nothing to the hair? Or rush to your hair stylist only on your wedding day? 
                    Well that might give you a temporary solution but as a bride don’t you want that luscious voluminous hair all the time? 
                    Even after the day after the wedding, don’t you want to dazzle everyone’s eyes with your healthy hair at your in laws place with 
                    the least effort? If so then we are here for you girl!
                </p>
                <a href="https://www.brideeveryday.com/hair-care-tips-brides" class="btn body-btn">View More</a>
                </div>
            </div>
</div>
<section class="food-delight">
        <div class="container">
            <div class="info">
                <div class="animate-left">
                    <div class="global-headline">
                        <h2 class="sub-headline">
                            <span class="first-letter">W</span>ays 
                        </h2>
                        <h1 class="headline">To Make Henna Darker</h1>
                        <div class="asterisk"<i class="fas fa-asterisk"></i></div>
                    </div>
                    <a href="#" class="btn body-btn">View More</a>
                    <p>
                        Every bride's dream is to get a henna stain for her wedding.It is a once in a lifetime occasion for the bride and they have every right to steal the show.
                    </p>
                    <a href="https://www.theknot.com/content/henna-designs" class="btn body-btn">View More</a>
                </div>
                <div class="food-delight-img">
                   <img class="animate-top" src="ht6.jpg"  width="500" height="200">
                   <img class="animate-bottom" src="ht7.jpg"   width="500" height="200">
                </div>  
            </div>
        </div>
    </section>


<script src="main.js"></script>
</body>
</html>
